import { useEffect, useRef, useState } from "react";

export default function MessageInput({ onSend, onTyping, disabled }) {
  const [text, setText] = useState("");
  const typingRef = useRef(false);
  const stopTimer = useRef(null);

  function stopTyping() {
    clearTimeout(stopTimer.current);
    if (typingRef.current) {
      typingRef.current = false;
      onTyping(false);
    }
  }

  const handleChange = (e) => {
    setText(e.target.value);
    // Tell others we're typing once, then again "stopped" after 1.5s of silence
    if (!typingRef.current) {
      typingRef.current = true;
      onTyping(true);
    }
    clearTimeout(stopTimer.current);
    stopTimer.current = setTimeout(stopTyping, 1500);
  };

  const submit = async (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    stopTyping();
    const ok = await onSend(value);
    if (ok) setText("");
  };

  useEffect(() => () => clearTimeout(stopTimer.current), []);

  return (
    <form className="composer" onSubmit={submit}>
      <input
        value={text}
        onChange={handleChange}
        placeholder={disabled ? "Connecting…" : "Type a message"}
        maxLength={1000}
        disabled={disabled}
        autoFocus
      />
      <button className="btn primary" disabled={disabled || !text.trim()}>
        Send
      </button>
    </form>
  );
}
