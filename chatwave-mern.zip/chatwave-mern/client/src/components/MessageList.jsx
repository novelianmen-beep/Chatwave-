import { useLayoutEffect, useRef } from "react";

const formatTime = (iso) =>
  new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

export default function MessageList({ messages, meId, hasMore, loadingOlder, onLoadOlder }) {
  const ref = useRef(null);
  const prev = useRef({ firstId: null, lastId: null, height: 0 });

  // Scroll behaviour:
  //  - older messages were loaded at the top -> keep the view where it was
  //  - a new message arrived -> scroll down if we were near the bottom (or it's ours)
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const first = messages[0]?._id;
    const last = messages[messages.length - 1]?._id;
    const p = prev.current;

    if (p.firstId && first !== p.firstId && last === p.lastId) {
      el.scrollTop = el.scrollHeight - p.height;
    } else if (last !== p.lastId) {
      const wasNearBottom = p.height - el.scrollTop - el.clientHeight < 150;
      const isMine = messages[messages.length - 1]?.sender?._id === meId;
      if (!p.lastId || wasNearBottom || isMine) el.scrollTop = el.scrollHeight;
    }
    prev.current = { firstId: first, lastId: last, height: el.scrollHeight };
  }, [messages, meId]);

  return (
    <div className="messages" ref={ref}>
      {hasMore && (
        <button className="btn ghost sm load-older" onClick={onLoadOlder} disabled={loadingOlder}>
          {loadingOlder ? "Loading…" : "Load older messages"}
        </button>
      )}

      {messages.length === 0 && (
        <p className="muted center empty">No messages yet. Say hello! 👋</p>
      )}

      {messages.map((m, i) => {
        const mine = m.sender?._id === meId;
        const showName = i === 0 || messages[i - 1].sender?._id !== m.sender?._id;
        return (
          <div key={m._id} className={`msg-row ${mine ? "mine" : ""}`}>
            <div className="bubble">
              {showName && !mine && <span className="sender">{m.sender?.name || "Unknown"}</span>}
              <p>{m.text}</p>
              <time>{formatTime(m.createdAt)}</time>
            </div>
          </div>
        );
      })}
    </div>
  );
}
