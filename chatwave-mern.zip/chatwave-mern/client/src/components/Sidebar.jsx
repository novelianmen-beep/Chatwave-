import { useState } from "react";

export default function Sidebar({
  rooms,
  activeId,
  user,
  connected,
  open,
  onSelect,
  onCreate,
  onLogout,
}) {
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    const err = await onCreate(name);
    if (err) setError(err);
    else {
      setName("");
      setError("");
    }
  };

  return (
    <aside className={`sidebar ${open ? "open" : ""}`}>
      <div className="logo">💬 ChatWave</div>

      <h3 className="side-title">Rooms</h3>
      <ul className="room-list">
        {rooms.map((r) => (
          <li key={r._id}>
            <button
              className={`room ${r._id === activeId ? "active" : ""}`}
              onClick={() => onSelect(r._id)}
            >
              # {r.name}
            </button>
          </li>
        ))}
      </ul>

      <form className="new-room" onSubmit={submit}>
        <input
          placeholder="New room name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={30}
        />
        <button className="btn primary sm" disabled={name.trim().length < 2}>
          +
        </button>
      </form>
      {error && <p className="side-error">{error}</p>}

      <div className="me">
        <div className="avatar">{user.name[0].toUpperCase()}</div>
        <div className="me-info">
          <strong>{user.name}</strong>
          <span className="muted">
            <span className={`dot ${connected ? "on" : "off"}`} />
            {connected ? "Connected" : "Offline"}
          </span>
        </div>
        <button className="btn ghost sm" onClick={onLogout}>
          Log out
        </button>
      </div>
    </aside>
  );
}
